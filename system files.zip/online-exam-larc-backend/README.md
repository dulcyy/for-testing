Project Name: Online Web Examination App

Project Description:
This side of the project provides the API necessary for the project web application. 

Framework Used: Laravel

Developer/s: Donna Chelsey V. Dagcuta

<br>
Main features: 
<li> Admin can register another admin, create exam and attach questions to exam, view applicants' exam scores. <br>
<li> Applicant can register, take exams and view their scores. </li>

<br>
Notes: <br>
<li> Thunder Client API file included in the repository 
<li> For a detailed view of the API, please refer to the project sheet. Permission to view is, as of writing, granted to "anyone with link". Please ask sir Fabian for the link. 
