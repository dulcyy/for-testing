import React from 'react'

const Error404Page = () => {
  return (
    <div>Error404Page</div>
  )
}

export default Error404Page