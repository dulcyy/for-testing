import React from 'react';
import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Router, Routes } from 'react-router-dom';
import DashboardPage from './authenticated/screens/dashboard/dashboard';
import HomePage from './authenticated/screens/home/home';
import Error404Page from './404';

function App() {
  return (
   <BrowserRouter>
    <Routes>
      <Route path="/" element={<HomePage/>}></Route>
      <Route path="/dashboard" element={<DashboardPage/>}></Route>
      <Route path="*" element={<Error404Page/>}></Route>
    </Routes>
   </BrowserRouter> 
  );
}

export default App;
